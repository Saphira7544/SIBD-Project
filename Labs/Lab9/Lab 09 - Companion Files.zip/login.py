#!/usr/bin/python3

IST_ID = 'ist1XXXXX'
host = 'db.tecnico.ulisboa.pt'
port = 5432
password = 'XXXXXXXX'
db_name = IST_ID

credentials = 'host={} port={} user={} password={} dbname={}'.format(host, port, IST_ID, password, db_name)
